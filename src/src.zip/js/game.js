  (function() {
    'use strict';

    function Game() {
      this.player = null;
      this.lastx;
      this.lasty;
      this.facing = 'left';
      this.cursors;
      this.scoreString = null;
      this.scoreText = null;
      this.score = null;
      this.jumpButton = null;
      this.jumpTimer = 0;
      this.emitter;
      this.coins;
      this.kgreens;
      this.kblues;
      this.kreds;
      this.kyellows;
      this.spikes;
      this.water;
      this.lava;
      this.inwater;
      this.green=false;
      this.blue=false;
      this.red=false;
      this.yellow=false;
      this.fish;
      this.caracol;
      this.fly;
      this.venemyc=-100;
      this.venemyf=-150;
      this.venemym=-150;
      this.lastimec=5000;
      this.lastimef=5000;
      this.lastimem=3000;
      
      this.map;
      this.layer;
      this.music;
      this.victory;
      this.coinf;
      this.keys;
    }

    Game.prototype = {

      create: function () {
        var x = this.game.width / 2
        , y = this.game.height / 2;
        this.music = this.game.add.audio('musicLoop', 1, true);
        this.music.play('', 0, 1, true);
        this.victory = this.game.add.audio('victory');
        this.coinf = this.game.add.audio('coins');
        this.keys = this.game.add.audio('keys');

        this.physics.startSystem(Phaser.Physics.ARCADE);

        //Score
        this.scoreString = 'Score : ';
        this.scoreText = this.add.text(10, 30, this.scoreString + this.score, { fontSize: '34px', fill: '#fff' });

        this.stage.backgroundColor = '##38ffff';

        //Map and map collisions
        this.map = this.game.add.tilemap('map');
        this.map.addTilesetImage('tiled');
        this.map.setCollision(1);
        this.map.setCollision(2);
        this.map.setCollision(3);
        this.map.setCollision(10);
        this.map.setCollision(11);
        this.map.setCollision(12);
        this.map.setCollision(13);
        this.map.setCollision(14);
        this.map.setCollision(15);
        this.map.setCollision(16);
        this.map.setCollision(17);
        this.map.setCollision(18);
        this.map.setCollision(19);
        this.map.setCollision(20);
        
        //layer
        this.layer = this.map.createLayer('layer1');
        this.layer.resizeWorld();
        //this.layer.debug = true;

        //coin animation
        this.coins = this.add.group();
        this.coins.enableBody = true;
        this.coins.physicsBodyType = Phaser.Physics.ARCADE;
        this.map.createFromObjects('coins', 45, 'coin', 0, true, false, this.coins);
        this.coins.callAll('animations.add', 'animations', 'spin', [0, 1, 2, 3, 4, 5], 10, true);
        this.coins.callAll('animations.play', 'animations', 'spin');
        this.coins.setAll('body.collideWorldBounds', true);

        //key green
        this.kgreens = this.add.group();
        this.kgreens.enableBody = true;
        this.kgreens.physicsBodyType = Phaser.Physics.ARCADE;
        this.map.createFromObjects('kgreen', 21, 'kgreen', 0, true, false, this.kgreens);
        this.kgreens.callAll('animations.add', 'animations', 'spinn', [0], 10, true);
        this.kgreens.callAll('animations.play', 'animations', 'spinn');
        this.kgreens.setAll('body.collideWorldBounds', true);

        //key blue collision
        this.kblues = this.add.group();
        this.kblues.enableBody = true;
        this.kblues.physicsBodyType = Phaser.Physics.ARCADE;
        this.map.createFromObjects('kblue', 22, 'kblue', 0, true, false, this.kblues);
        this.kblues.callAll('animations.add', 'animations', 'spinn', [0], 10, true);
        this.kblues.callAll('animations.play', 'animations', 'spinn');
        this.kblues.setAll('body.collideWorldBounds', true);

        //key red collision
        this.kreds = this.add.group();
        this.kreds.enableBody = true;
        this.kreds.physicsBodyType = Phaser.Physics.ARCADE;
        this.map.createFromObjects('kred', 37, 'kred', 0, true, false, this.kreds);
        this.kreds.callAll('animations.add', 'animations', 'spinn', [0], 10, true);
        this.kreds.callAll('animations.play', 'animations', 'spinn');
        this.kreds.setAll('body.collideWorldBounds', true);

        //key yellow collision
        this.kyellows = this.add.group();
        this.kyellows.enableBody = true;
        this.kyellows.physicsBodyType = Phaser.Physics.ARCADE;
        this.map.createFromObjects('kyellow', 36, 'kyellow', 0, true, false, this.kyellows);
        this.kyellows.callAll('animations.add', 'animations', 'spinn', [0], 10, true);
        this.kyellows.callAll('animations.play', 'animations', 'spinn');
        this.kyellows.setAll('body.collideWorldBounds', true);
        
        //Spikes collision
        this.spikes = this.add.group();
        this.spikes.enableBody = true;
        this.spikes.physicsBodyType = Phaser.Physics.ARCADE;
        this.map.createFromObjects('spikes', 35, 'spikes', 0, true, false, this.spikes);
        this.spikes.callAll('animations.add', 'animations', 'spinn', [0], 10, true);
        this.spikes.callAll('animations.play', 'animations', 'spinn');
        this.spikes.setAll('body.collideWorldBounds', true);



      //player  
      this.player = this.add.sprite(32, 1500, 'dude');
      this.physics.arcade.enable(this.player);
      this.player.body.linearDamping = 1;
      this.player.body.collideWorldBounds = true;
      this.player.anchor.setTo(0.5, 0.5);
      this.player.body.gravity.y=450;

      this.caracol= this.add.group();
      this.caracol.enableBody = true;
      this.caracol.physicsBodyType = Phaser.Physics.ARCADE;
      this.caracol.setAll('body.collideWorldBounds', true);
        
        
      this.fish= this.add.group();
      this.fish.enableBody = true;
      this.fish.physicsBodyType = Phaser.Physics.ARCADE;
      this.fish.setAll('body.collideWorldBounds', true);
        
      this.fly= this.add.group();
      this.fly.enableBody = true;
      this.fly.physicsBodyType = Phaser.Physics.ARCADE;
      this.fly.setAll('body.collideWorldBounds', true);
      //enemigos lista
      this.caracol.create(1315.89 ,606.5 , 'caracol');
      this.caracol.create(1300.5 ,1866.5 , 'caracol');
      this.caracol.create(1203.69 ,886.5 , 'caracol');
      this.caracol.create(6092.29 ,956.5 , 'caracol');
      this.caracol.create(5996.1 ,606.5 , 'caracol');
      this.fish.create(4076.89 ,1966.5 , 'pez');
      this.fish.create(4850.09 ,1966.5 , 'pez');
      this.fish.create(5250.09 ,1966.5 , 'pez');
      this.fly.create(3547.10 ,1096.5 , 'fly');
      this.fly.create(4047.10 ,1096.5 , 'fly');
      this.fly.create(4547.10 ,1096.5 , 'fly');
      this.fly.create(5727.3 ,536.5 , 'fly');


      //last position
      this.lastx=32;
      this.lasty=1500;

      this.camera.follow(this.player);
      this.cursors = this.input.keyboard.createCursorKeys();
      this.jumpButton = this.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
      
    },

    update: function () {
      
      this.player.body.gravity.y=450;
      if (this.game.time.now > this.lastimec)
      {
          this.venemyc=this.venemyc*-1;
          this.lastimec = this.game.time.now + 5000;
      }
      if (this.game.time.now > this.lastimef)
      {
          this.venemyf=this.venemyf*-1;
          this.lastimef = this.game.time.now + 5000;
      }
      if (this.game.time.now > this.lastimem)
      {
          this.venemym=this.venemym*-1;
          this.lastimem = this.game.time.now + 5000;
      }
      
      this.caracol.setAll('body.velocity.x', this.venemyc);
      this.fish.setAll('body.velocity.x', this.venemyf);
      this.fly.setAll('body.velocity.x', this.venemyf);
       this.physics.arcade.collide(this.player, this.layer);
      
      this.physics.arcade.collide(this.player, this.caracol, function (player, veg) {
        this.player.x=this.lastx;
        this.player.y=this.lasty;
      }, null, this);
      
      this.physics.arcade.collide(this.player, this.fish, function (player, veg) {
        this.player.x=this.lastx;
        this.player.y=this.lasty;
      }, null, this);
      
      this.physics.arcade.collide(this.player, this.fly, function (player, veg) {
        this.player.x=this.lastx;
        this.player.y=this.lasty;
      }, null, this);

       //coin animation and collition
       this.physics.arcade.overlap(this.player, this.coins, function (player, coin) {
            coin.kill();
            this.coinf.play();
        }, null, this);

       //key green collision
       this.physics.arcade.overlap(this.player, this.kgreens, function (player, key) {
            this.keys.play();
            key.kill();
            player.x=2972.7;
            player.y=1166.5;
            this.lastx=2972.7;
            this.lasty=1166.5;
            this.player.body.velocity.y= -300;
            this.green=true;
        }, null, this);

       //key blue collision
       this.physics.arcade.overlap(this.player, this.kblues, function (player, key) {
            this.keys.play();
            key.kill();
            player.x=4175.9;
            player.y=1166.5;
            this.lastx=4175.9;
            this.lasty=1166.5;
            this.player.body.velocity.y= -300;
            this.blue=true;
        }, null, this);

       //key red collision
       this.physics.arcade.overlap(this.player, this.kreds, function (player, key) {
            this.keys.play();
            key.kill();
            player.x=6963.7;
            player.y=886.5;
            this.lastx=6963.7;
            this.lasty=886.5;
            this.player.body.velocity.y= -300;
            this.red=true;
        }, null, this);

       //key yellow collision
       this.physics.arcade.overlap(this.player, this.kyellows, function (player, key) {
            this.keys.play();
            key.kill();
            player.x=7922.09;
            player.y=256.5;
            this.lastx=7922.09;
            this.lasty=256.5;
            this.player.body.velocity.y= -300;
            this.yellow=true;
        }, null, this);

       //Spikes collision
       this.physics.arcade.overlap(this.player, this.spikes, function (player, spikes) {
            player.x=this.lastx;
            player.y=this.lasty;
            this.player.body.velocity.y= -300;
        }, null, this);

      //water collide
        this.map.setTileIndexCallback(6, function (player, tile) {
          this.player.body.gravity.y=50;
            if (this.jumpButton.isDown && this.game.time.now > this.jumpTimer)
            {
                  this.player.body.velocity.y = -100;
            }
            return false;

        }, this);

        //lava collide
        this.map.setTileIndexCallback(9, function (sprite, tile) {
            this.player.x=this.lastx;
            this.player.y=this.lasty;
            this.player.body.velocity.y = -300;
            return false;

        }, this);

        //flag green
        this.map.setTileIndexCallback(29, function (sprite, tile) {
            this.lastx=2972.7;
            this.lasty=1166.5;
            return false;
        }, this);

        //flag blue
        this.map.setTileIndexCallback(30, function (sprite, tile) {
            this.lastx=4175.9;
            this.lasty=1166.5;
            return false;

        }, this);

        //flag red
        this.map.setTileIndexCallback(28, function (sprite, tile) {
            this.lastx=6963.7;
            this.lasty=886.5;
            return false;
        }, this);
      
        //flag yellow
        this.map.setTileIndexCallback(27, function (sprite, tile) {
            if(this.green && this.blue && this.red && this.yellow)
            {
                this.victory.play();
                this.game.state.start('menu');
            }
            return false;

        }, this);
      
       this.player.body.angularAcceleration = 0;
       if (this.cursors.left.isDown) {
          this.player.body.velocity.x= -200;
          this.player.angle -= 10;
       } else if (this.cursors.right.isDown) {
          this.player.body.velocity.x = 200;
          this.player.angle += 10;
        } else {
          this.player.body.velocity.x= 0;
        }

        if (this.jumpButton.isDown && this.game.time.now > this.jumpTimer)
        {
          if (this.player.body.onFloor())
          {
              this.player.body.velocity.y = -300;
          }
        }      
    },


    onInputDown: function () {
      this.game.state.start('menu');
    }

  };

  window['molecule-power'] = window['molecule-power'] || {};
  window['molecule-power'].Game = Game;

}());
