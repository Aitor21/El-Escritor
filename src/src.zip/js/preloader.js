(function() {
  'use strict';

  function Preloader() {
    this.asset = null;
    this.ready = false;
  }

  Preloader.prototype = {

    preload: function () {
      this.asset = this.add.sprite(320, 240, 'preloader');
      this.asset.anchor.setTo(0.5, 0.5);

      this.load.onLoadComplete.addOnce(this.onLoadComplete, this);
      this.load.setPreloadSprite(this.asset);
      this.load.image('player', 'assets/player.png');
      this.load.bitmapFont('minecraftia', 'assets/minecraftia.png', 'assets/minecraftia.xml');
        
      this.load.tilemap('map', 'assets/map.json', null, Phaser.Tilemap.TILED_JSON);
      //this.load.tilemap('map', 'assets/features_test.json', null, Phaser.Tilemap.TILED_JSON);

      this.load.image('tiled', 'assets/tiled.png'); 
    this.load.image('dude', 'assets/hud_p1.png', 47, 47);
    this.load.spritesheet('kgreen', 'assets/keyGreen.png', 70, 70);
    this.load.spritesheet('kblue', 'assets/keyBlue.png', 70, 70);
    this.load.spritesheet('kred', 'assets/keyRed.png', 70, 70);
    this.load.spritesheet('kyellow', 'assets/keyYellow.png', 70, 70);
    this.load.spritesheet('spikes', 'assets/spikes.png', 70, 70);
    this.load.spritesheet('water', 'assets/liquidWater.png', 70, 70);
    this.load.spritesheet('lava', 'assets/liquidLava.png', 70, 70);
    this.load.spritesheet('pez', 'assets/fishSwim1.png', 66, 42);
    this.load.spritesheet('caracol', 'assets/snailWalk1.png', 54, 31);
    this.load.spritesheet('fly', 'assets/flyFly1.png', 72, 36);
    this.load.spritesheet('coin', 'assets/coin.png', 32, 32);
    this.load.audio('musicLoop', 'assets/Jaunty.mp3');
    this.load.audio('victory', 'assets/victory.mp3');
    this.load.audio('coins', 'assets/coin.mp3');
    this.load.audio('keys', 'assets/llaves.mp3');

    },

    create: function () {
      this.asset.cropEnabled = false;
    },

    update: function () {
      if (!!this.ready) {
        this.game.state.start('menu');
      }
    },

    onLoadComplete: function () {
      this.ready = true;
    }
  };

  window['molecule-power'] = window['molecule-power'] || {};
  window['molecule-power'].Preloader = Preloader;

}());
